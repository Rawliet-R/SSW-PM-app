# SSW PM Master App 🇯🇵

Aplikasi belajar **SSW PM (Sektor Manufaktur Makanan)** untuk persiapan ujian **Tokutei Ginou (特定技能)** — berbasis React + Vite, offline-ready (PWA).

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Jalankan development server
npm run dev

# 3. Buka di browser
# → http://localhost:5173
```

---

## 📦 Build untuk Production

```bash
npm run build
npm run preview
```

---

## 🗂 Struktur Project

```
ssw-pm-app/
├── public/
│   ├── data/
│   │   └── ssw_pm_master_db.json   ← Database utama (JANGAN diedit manual)
│   ├── icons/                      ← PWA icons
│   └── manifest.json               ← PWA manifest
│
├── src/
│   ├── context/
│   │   └── AppContext.jsx           ← Global state (data, progress, bookmarks, darkMode)
│   │
│   ├── pages/
│   │   ├── HomePage.jsx            ← Beranda (kategori + statistik progress)
│   │   ├── LessonPage.jsx          ← Detail pelajaran (tabs: Materi, Kosakata, Quiz)
│   │   ├── FlashcardPage.jsx       ← Sesi flashcard (flip + mark known/unknown)
│   │   ├── QuizPage.jsx            ← Sesi quiz (score + review jawaban salah)
│   │   ├── SearchPage.jsx          ← Pencarian global (pelajaran + kosakata)
│   │   └── BookmarksPage.jsx       ← Tersimpan + Progress tracker
│   │
│   ├── components/
│   │   └── BottomNav.jsx           ← Navigasi bawah
│   │
│   ├── App.jsx                     ← Router
│   ├── main.jsx                    ← Entry point
│   └── index.css                   ← Design system + dark mode
│
├── index.html
├── vite.config.js                  ← Vite + PWA config
└── package.json
```

---

## ✨ Fitur

### 📚 Learning System
- 3 kategori: Industry Overview, Food Hygiene, Labor Safety
- 14 pelajaran lengkap
- Konten JP + Indonesia dengan toggle bahasa
- Key points per pelajaran

### 🎴 Flashcard System
- Flip card animasi 3D (tap untuk balik)
- Tandai "Hafal ✅" / "Belum Hafal ❌"
- Statistik sesi (hafal vs belum)
- Ulangi hanya yang belum hafal

### 🧪 Quiz System
- Multiple choice, satu soal per layar
- Auto-advance setelah menjawab
- Score tracking + persentase
- Review jawaban salah di akhir
- Ulangi hanya soal yang salah

### 🔍 Search
- Cari pelajaran (judul, kategori, konten)
- Cari kosakata (JP dan Indonesia)
- Filter: Semua / Pelajaran / Kosakata
- Highlight kata yang dicari
- Quick-search chips (HACCP, 5S, dll.)

### 📊 Progress Tracking
- localStorage (tidak perlu login)
- Status selesai per pelajaran
- Skor quiz tersimpan
- Ringkasan di halaman Tersimpan → Progress

### ⭐ Bookmark
- Simpan pelajaran favorit
- Simpan kosakata
- Akses cepat ke flashcard & quiz dari bookmark

### 🌙 Dark Mode
- Toggle di header beranda
- Tersimpan otomatis ke localStorage

### 📱 PWA / Offline
- Install sebagai app di HP
- Cache asset untuk offline
- Service worker via vite-plugin-pwa

---

## 🛠 Tech Stack

| Layer | Tech |
|-------|------|
| Framework | React 18 |
| Build | Vite 5 |
| Routing | React Router v6 |
| State | Context API |
| Storage | localStorage |
| PWA | vite-plugin-pwa + Workbox |
| Fonts | Noto Sans JP + DM Sans (Google Fonts) |
| Styling | Pure CSS (Custom Properties) |

---

## 📊 Data

Database JSON diload dari `/public/data/ssw_pm_master_db.json`.

Format data:
```json
{
  "app_meta": { "name", "version", "module", "published" },
  "categories": [
    {
      "id": "food_hygiene",
      "name": "Sanitasi & Kebersihan Pangan",
      "lessons": [
        {
          "lesson_id": "FH_01",
          "title": "...",
          "content_jp": "...",
          "content_id": "...",
          "main_points": [...],
          "vocab": [{ "id", "jp", "indo" }],
          "quiz": [{ "question", "options", "answer" }]
        }
      ]
    }
  ]
}
```

---

## 🔧 Kustomisasi

### Mengganti data
Ganti file `public/data/ssw_pm_master_db.json` dengan format yang sama.

### Menambah kategori warna
Edit `CAT_META` di `src/pages/HomePage.jsx`.

### Mengubah warna tema
Edit CSS variables di `src/index.css` blok `:root` dan `.dark`.

---

## 📱 Install sebagai App (PWA)

1. Buka `npm run preview` atau deploy ke server HTTPS
2. Di Chrome/Edge: klik ikon install di address bar
3. Di Safari iOS: Share → Add to Home Screen

---

*Data source: SSW PM Master Database — Modul Kuning Tokutei Ginou Inshoku Ryouhin Seizougyou*
